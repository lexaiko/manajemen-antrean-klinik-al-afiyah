<?php $__env->startSection('content'); ?>
    <section class="jumbotron w-full" style="height: 33vh; min-height: 180px;">
        <div class="relative w-full h-full overflow-hidden">
            <img class="w-full h-full object-cover" src="<?php echo e(url('images/hero-bg.jpg')); ?>" alt="" style="height: 100%; object-fit: cover;">
        </div>
    </section>
        <div class="relative z-10 flex justify-center items-center w-full">
            <div
                class="flex flex-col justify-center items-center p-4 bg-white shadow-lg rounded-lg -mt-8 mb-5 w-[95%] max-w-4xl">
                <div class="w-full">
                    
                    <div class="flex flex-col md:flex-row md:justify-between md:items-center mb-4 gap-2">
                        <form method="GET" action="<?php echo e(route('antrean.index')); ?>"
                            class="flex items-center gap-2 w-full md:w-auto">
                            <label for="filter" class="block text-sm font-medium text-gray-700 mr-2">Filter Poli:</label>
                            <select id="filter" name="filter" onchange="this.form.submit()"
                                class="form-select block w-full md:w-48 rounded-lg border-gray-300 focus:border-green-500 focus:ring-green-500 text-sm">
                                <option value="">Semua Poli</option>
                                <?php $__currentLoopData = $polis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($poli->id); ?>"
                                        <?php echo e(request('filter') == $poli->id ? 'selected' : ''); ?>>
                                        <?php echo e($poli->nama_poli); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </form>
                    </div>
                    
                    <div class="flex justify-center items-center">
                        <h1 class="py-3 text-base md:text-lg font-semibold text-gray-700">
                            <?php echo e($todayFormatted); ?>

                        </h1>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="min-w-full text-sm text-left text-gray-600">
                            <thead class="text-xs text-gray-700 uppercase bg-gray-100 rounded-lg">
                                <tr>
                                    <th scope="col" class="px-4 py-3 text-center">Inisial</th>
                                    <th scope="col" class="px-4 py-3 text-center">Nomor Antrean</th>
                                    <th scope="col" class="px-4 py-3 text-center">Poli Tujuan</th>
                                    <th scope="col" class="px-4 py-3 text-center">Status Antrean</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $antrian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $antri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="border-b hover:bg-gray-50">
                                        <td class="text-center align-middle p-2">
                                            <?php echo e($antri->inisial_nama ?? '-'); ?>

                                        </td>
                                        <td class="text-center align-middle p-2">
                                            <?php echo e($antri->nomor_antrian); ?>

                                        </td>
                                        <td class="text-center align-middle p-2">
                                            Poli <?php echo e($antri->polis->nama_poli ?? '-'); ?>

                                        </td>
                                        <td class="text-center align-middle p-2">
                                            <?php echo e($antri->status); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" class="text-center text-gray-500 py-4">
                                            Belum ada antrean hari ini
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\coding\laravel\simak\resources\views\antrean\index.blade.php ENDPATH**/ ?>